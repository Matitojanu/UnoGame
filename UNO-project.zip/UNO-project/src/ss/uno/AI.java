package ss.uno;

public class AI {

}
