package ss.uno;

public class Board {
    
}
