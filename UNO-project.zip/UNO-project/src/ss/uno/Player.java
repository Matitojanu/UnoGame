package ss.uno;

public interface Player {
    public void determineMove();
}
