package ss.uno;

public class ReverseCard {
}
