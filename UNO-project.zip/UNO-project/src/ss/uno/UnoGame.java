package ss.uno;

public class UnoGame {
    private Board board;
    private Player player1;
    private Player player2;
    private Player playersTurn;

    public void getTurn(){

    }

    public void getWinner(){

    }

    public void isGameOver(){
        
    }

    public void playCard(){

    }

    public void drawCard(){

    }
}
