package ss.uno;

public class UnoTUI {
    public void run(){

    }
    public static void main(String[] args) {

    }
}